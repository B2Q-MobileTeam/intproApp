// import 'package:flutter/material.dart';

// class Product {
//   int id;
//   String flowerName;
//   String flowerImageURL;
//   String cid;

//   Product(
//       {@required this.id,
//       @required this.flowerName,
//       @required this.cid,
//       @required this.flowerImageURL});
// }

// class Products with ChangeNotifier {
//   List<Product> _items = [


//   var apiURL =
//       'https://www.binary2quantumsolutions.com/intpro/category.php';

//   ];

//   List<Product> get items {
//     return [..._items];
//   }

//   Product findById(String id) {
//     return _items.firstWhere((PdtItem) => PdtItem.id == id);
//   }
// }
