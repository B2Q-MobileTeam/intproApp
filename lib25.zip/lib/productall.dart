// import 'package:flutter/material.dart';
// import 'Dashboardfragment.dart';
//
// import 'brands.dart';
//
//
// class product_all extends StatelessWidget {
//   const product_all(this.dashboardpro);
//   @required
//   //final DashboardProducts dashboardpro;
//
//   @override
//   Widget build(BuildContext context) {
//     return
//       ListTile(
//         title: Text(
//           dashboardpro.catergoryname,
//           textAlign: TextAlign.start,
//         ),
//        // trailing:
//         //IconButton(icon: Icon(Icons.arrow_right), onPressed: null),
//       );
//   }
//
//   }
//
// // const Secbrand(this.brandss);
// // @required
// // final Brandss brandss;
// // @override
// // Widget build(BuildContext context) {
// //   return Center(
// //       child: Card(
// //     clipBehavior: Clip.hardEdge,
// //     elevation: 10.0,
// //     child: Column(
// //       children: [
// //         ListTile(
// //           title: Text(
// //             brandss.brandsname,
// //             textAlign: TextAlign.start,
// //           ),
// //           trailing:
// //               IconButton(icon: Icon(Icons.arrow_right), onPressed: null),
// //         )
// //       ],
// //     ),
// //   ));
// // }
// //}
